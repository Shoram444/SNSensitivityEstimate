| **process**                        | **bkg counts in ROI** |
|:-----------------------------------|:----------------------|
| bb\_foil\_bulk                     | 1.39287e5             |
| Bi214\_foil\_bulk                  | 11.2313               |
| Bi214\_radon                       | 19.3356               |
| Tl208\_foil\_bulk                  | 1.67425               |
| K40\_foil\_bulk                    | 20839.5               |
| Pa234m\_foil\_bulk                 | 25837.0               |
| neutron\_external\nfull\_shielding | 0.468315              |
| total                              | 1.85996e5             |
