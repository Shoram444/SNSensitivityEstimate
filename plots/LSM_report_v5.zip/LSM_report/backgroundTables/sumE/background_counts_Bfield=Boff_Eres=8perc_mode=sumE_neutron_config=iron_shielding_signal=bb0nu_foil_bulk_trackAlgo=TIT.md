| **process**                        | **bkg counts in ROI** |
|:-----------------------------------|:----------------------|
| bb\_foil\_bulk                     | 0.587872              |
| Bi214\_foil\_bulk                  | 0.0689365             |
| Bi214\_radon                       | 0.0953791             |
| Tl208\_foil\_bulk                  | 0.0204843             |
| K40\_foil\_bulk                    | 0.0                   |
| Pa234m\_foil\_bulk                 | 0.0                   |
| neutron\_external\niron\_shielding | 1.07756               |
| total                              | 1.85023               |
