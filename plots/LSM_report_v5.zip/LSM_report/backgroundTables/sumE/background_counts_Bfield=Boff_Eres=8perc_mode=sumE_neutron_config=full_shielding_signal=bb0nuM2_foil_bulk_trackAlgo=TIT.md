| **process**                        | **bkg counts in ROI** |
|:-----------------------------------|:----------------------|
| bb\_foil\_bulk                     | 37381.0               |
| Bi214\_foil\_bulk                  | 5.61005               |
| Bi214\_radon                       | 7.40913               |
| Tl208\_foil\_bulk                  | 0.285338              |
| K40\_foil\_bulk                    | 1.32358               |
| Pa234m\_foil\_bulk                 | 3685.03               |
| neutron\_external\nfull\_shielding | 0.215124              |
| total                              | 41080.9               |
