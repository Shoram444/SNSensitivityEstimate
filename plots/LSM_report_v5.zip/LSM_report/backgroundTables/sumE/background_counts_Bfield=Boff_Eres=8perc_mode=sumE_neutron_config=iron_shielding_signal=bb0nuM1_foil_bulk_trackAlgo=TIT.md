| **process**                        | **bkg counts in ROI** |
|:-----------------------------------|:----------------------|
| bb\_foil\_bulk                     | 22.3685               |
| Bi214\_foil\_bulk                  | 0.267995              |
| Bi214\_radon                       | 0.318607              |
| Tl208\_foil\_bulk                  | 0.023279              |
| K40\_foil\_bulk                    | 0.0                   |
| Pa234m\_foil\_bulk                 | 0.0                   |
| neutron\_external\niron\_shielding | 1.35748               |
| total                              | 24.3359               |
