| **process**                                    | **bkg counts in ROI** |
|:-----------------------------------------------|:----------------------|
| bb\_foil\_bulk                                 | 22.3685               |
| Bi214\_foil\_bulk                              | 0.274924              |
| Bi214\_radon                                   | 0.322665              |
| Tl208\_foil\_bulk                              | 0.0303994             |
| K40\_foil\_bulk                                | 0.0                   |
| Pa234m\_foil\_bulk                             | 0.0                   |
| neutron\_external\nno\_french\_wall\_shielding | 0.532945              |
| total                                          | 23.5295               |
