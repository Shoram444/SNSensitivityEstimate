| **process**        | **bkg counts in ROI** |
|:-------------------|:----------------------|
| bb\_foil\_bulk     | 1.39363e5             |
| Bi214\_foil\_bulk  | 11.247                |
| Bi214\_radon       | 19.3254               |
| Tl208\_foil\_bulk  | 1.67475               |
| K40\_foil\_bulk    | 20841.4               |
| Pa234m\_foil\_bulk | 25848.5               |
| total              | 1.86086e5             |
