| **process**                           | **bkg counts in ROI** |
|:--------------------------------------|:----------------------|
| bb\_foil\_bulk                        | 17.3618               |
| Bi214\_foil\_bulk                     | 0.269346              |
| Bi214\_radon                          | 0.296284              |
| Tl208\_foil\_bulk                     | 0.0307632             |
| K40\_foil\_bulk                       | 0.0                   |
| Pa234m\_foil\_bulk                    | 0.0                   |
| neutron\_external\ncurrent\_shielding | 0.183748              |
| total                                 | 18.142                |
