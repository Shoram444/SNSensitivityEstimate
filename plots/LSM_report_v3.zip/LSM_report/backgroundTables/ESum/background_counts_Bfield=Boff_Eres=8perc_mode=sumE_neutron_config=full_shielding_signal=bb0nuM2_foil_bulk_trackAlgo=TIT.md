| **process**                        | **bkg counts in ROI** |
|:-----------------------------------|:----------------------|
| bb\_foil\_bulk                     | 37411.5               |
| Bi214\_foil\_bulk                  | 5.61263               |
| Bi214\_radon                       | 7.41116               |
| Tl208\_foil\_bulk                  | 0.285592              |
| K40\_foil\_bulk                    | 1.32358               |
| Pa234m\_foil\_bulk                 | 3672.06               |
| neutron\_external\nfull\_shielding | 0.144786              |
| total                              | 41098.3               |
