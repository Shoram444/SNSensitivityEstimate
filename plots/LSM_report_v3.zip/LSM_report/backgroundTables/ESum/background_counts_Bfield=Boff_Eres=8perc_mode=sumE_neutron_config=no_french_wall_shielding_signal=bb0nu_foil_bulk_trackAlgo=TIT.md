| **process**                                    | **bkg counts in ROI** |
|:-----------------------------------------------|:----------------------|
| bb\_foil\_bulk                                 | 0.225351              |
| Bi214\_foil\_bulk                              | 0.0658831             |
| Bi214\_radon                                   | 0.0872617             |
| Tl208\_foil\_bulk                              | 0.0211775             |
| K40\_foil\_bulk                                | 0.0                   |
| Pa234m\_foil\_bulk                             | 0.0                   |
| neutron\_external\nno\_french\_wall\_shielding | 0.285849              |
| total                                          | 0.685522              |
