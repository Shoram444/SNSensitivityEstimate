| **process**                                    | **bkg counts in ROI** |
|:-----------------------------------------------|:----------------------|
| bb\_foil\_bulk                                 | 17.3618               |
| Bi214\_foil\_bulk                              | 0.263826              |
| Bi214\_radon                                   | 0.290196              |
| Tl208\_foil\_bulk                              | 0.0235851             |
| K40\_foil\_bulk                                | 0.0                   |
| Pa234m\_foil\_bulk                             | 0.0                   |
| neutron\_external\nno\_french\_wall\_shielding | 0.43165               |
| total                                          | 18.3711               |
