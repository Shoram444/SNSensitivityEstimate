| **process**                        | **bkg counts in ROI** |
|:-----------------------------------|:----------------------|
| bb\_foil\_bulk                     | 139290.0±37.0         |
| Bi214\_foil\_bulk                  | 11.24±0.026           |
| Bi214\_radon                       | 19.31±0.2             |
| Tl208\_foil\_bulk                  | 1.6739±0.005          |
| K40\_foil\_bulk                    | 20841.0±83.0          |
| Pa234m\_foil\_bulk                 | 25843.0±50.0          |
| neutron\_external\nfull\_shielding | 0.468±0.031           |
| total                              | 186010.0±100.0        |
