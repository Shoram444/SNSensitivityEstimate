| **process**                        | **bkg counts in ROI** |
|:-----------------------------------|:----------------------|
| bb\_foil\_bulk                     | 0.529±0.072           |
| Bi214\_foil\_bulk                  | 0.0731±0.0021         |
| Bi214\_radon                       | 0.085±0.013           |
| Tl208\_foil\_bulk                  | 0.02682±0.00063       |
| K40\_foil\_bulk                    | 0.0±0.0               |
| Pa234m\_foil\_bulk                 | 0.0±0.0               |
| neutron\_external\nfull\_shielding | 0.0302±0.0032         |
| total                              | 0.744±0.073           |
