| **process**                        | **bkg counts in ROI** |
|:-----------------------------------|:----------------------|
| bb\_foil\_bulk                     | 22.35±0.47            |
| Bi214\_foil\_bulk                  | 0.2678±0.004          |
| Bi214\_radon                       | 0.3±0.025             |
| Tl208\_foil\_bulk                  | 0.02358±0.00059       |
| K40\_foil\_bulk                    | 0.0±0.0               |
| Pa234m\_foil\_bulk                 | 0.0±0.0               |
| neutron\_external\niron\_shielding | 1.36±0.17             |
| total                              | 24.3±0.5              |
