| **process**                           | **bkg counts in ROI** |
|:--------------------------------------|:----------------------|
| bb\_foil\_bulk                        | 0.529±0.072           |
| Bi214\_foil\_bulk                     | 0.0718±0.0021         |
| Bi214\_radon                          | 0.085±0.013           |
| Tl208\_foil\_bulk                     | 0.02062±0.00055       |
| K40\_foil\_bulk                       | 0.0±0.0               |
| Pa234m\_foil\_bulk                    | 0.0±0.0               |
| neutron\_external\ncurrent\_shielding | 0.653±0.069           |
| total                                 | 1.36±0.1              |
