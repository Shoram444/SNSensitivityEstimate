| **process**                                    | **bkg counts in ROI** |
|:-----------------------------------------------|:----------------------|
| bb\_foil\_bulk                                 | 37393.0±19.0          |
| Bi214\_foil\_bulk                              | 5.611±0.018           |
| Bi214\_radon                                   | 7.43±0.12             |
| Tl208\_foil\_bulk                              | 0.286±0.0021          |
| K40\_foil\_bulk                                | 1.65±0.74             |
| Pa234m\_foil\_bulk                             | 3679.0±19.0           |
| neutron\_external\nno\_french\_wall\_shielding | 2.14±0.17             |
| total                                          | 41089.0±27.0          |
