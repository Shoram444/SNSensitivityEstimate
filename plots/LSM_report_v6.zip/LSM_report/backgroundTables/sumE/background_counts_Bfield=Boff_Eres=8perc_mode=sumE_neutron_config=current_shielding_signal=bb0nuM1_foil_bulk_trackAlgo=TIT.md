| **process**                           | **bkg counts in ROI** |
|:--------------------------------------|:----------------------|
| bb\_foil\_bulk                        | 22.35±0.47            |
| Bi214\_foil\_bulk                     | 0.2753±0.004          |
| Bi214\_radon                          | 0.306±0.025           |
| Tl208\_foil\_bulk                     | 0.03065±0.00068       |
| K40\_foil\_bulk                       | 0.0±0.0               |
| Pa234m\_foil\_bulk                    | 0.0±0.0               |
| neutron\_external\ncurrent\_shielding | 1.002±0.084           |
| total                                 | 23.96±0.48            |
