| **process**                                    | **bkg counts in ROI** |
|:-----------------------------------------------|:----------------------|
| bb\_foil\_bulk                                 | 0.529±0.072           |
| Bi214\_foil\_bulk                              | 0.0718±0.0021         |
| Bi214\_radon                                   | 0.085±0.013           |
| Tl208\_foil\_bulk                              | 0.02062±0.00055       |
| K40\_foil\_bulk                                | 0.0±0.0               |
| Pa234m\_foil\_bulk                             | 0.0±0.0               |
| neutron\_external\nno\_french\_wall\_shielding | 0.298±0.065           |
| total                                          | 1.005±0.098           |
