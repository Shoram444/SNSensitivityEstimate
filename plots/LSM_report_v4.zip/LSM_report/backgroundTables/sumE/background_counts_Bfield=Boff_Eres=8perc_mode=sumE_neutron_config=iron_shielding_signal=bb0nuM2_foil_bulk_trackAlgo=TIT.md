| **process**                        | **bkg counts in ROI** |
|:-----------------------------------|:----------------------|
| bb\_foil\_bulk                     | 37383.9               |
| Bi214\_foil\_bulk                  | 5.59766               |
| Bi214\_radon                       | 7.39289               |
| Tl208\_foil\_bulk                  | 0.279278              |
| K40\_foil\_bulk                    | 1.65448               |
| Pa234m\_foil\_bulk                 | 3677.52               |
| neutron\_external\niron\_shielding | 5.9634                |
| total                              | 41082.3               |
