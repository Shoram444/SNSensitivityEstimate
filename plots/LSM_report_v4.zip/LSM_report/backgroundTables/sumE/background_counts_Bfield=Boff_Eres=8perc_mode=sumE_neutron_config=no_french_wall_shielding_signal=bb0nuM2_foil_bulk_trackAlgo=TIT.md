| **process**                                    | **bkg counts in ROI** |
|:-----------------------------------------------|:----------------------|
| bb\_foil\_bulk                                 | 37391.3               |
| Bi214\_foil\_bulk                              | 5.61093               |
| Bi214\_radon                                   | 7.44971               |
| Tl208\_foil\_bulk                              | 0.286942              |
| K40\_foil\_bulk                                | 1.98537               |
| Pa234m\_foil\_bulk                             | 3679.77               |
| neutron\_external\nno\_french\_wall\_shielding | 2.13833               |
| total                                          | 41088.5               |
