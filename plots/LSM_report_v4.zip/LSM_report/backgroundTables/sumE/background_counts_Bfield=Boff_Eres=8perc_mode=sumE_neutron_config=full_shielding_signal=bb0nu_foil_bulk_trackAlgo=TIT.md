| **process**                        | **bkg counts in ROI** |
|:-----------------------------------|:----------------------|
| bb\_foil\_bulk                     | 0.568276              |
| Bi214\_foil\_bulk                  | 0.0712853             |
| Bi214\_radon                       | 0.089291              |
| Tl208\_foil\_bulk                  | 0.0273835             |
| K40\_foil\_bulk                    | 0.0                   |
| Pa234m\_foil\_bulk                 | 0.0                   |
| neutron\_external\nfull\_shielding | 0.0189803             |
| total                              | 0.775217              |
