| **process**                        | **bkg counts in ROI** |
|:-----------------------------------|:----------------------|
| bb\_foil\_bulk                     | 22.104                |
| Bi214\_foil\_bulk                  | 0.275218              |
| Bi214\_radon                       | 0.30846               |
| Tl208\_foil\_bulk                  | 0.0301486             |
| K40\_foil\_bulk                    | 0.0                   |
| Pa234m\_foil\_bulk                 | 0.0                   |
| neutron\_external\nfull\_shielding | 0.0259659             |
| total                              | 22.7438               |
