| **process**                        | **bkg counts in ROI** |
|:-----------------------------------|:----------------------|
| bb\_foil\_bulk                     | 37386.3               |
| Bi214\_foil\_bulk                  | 5.61093               |
| Bi214\_radon                       | 7.40913               |
| Tl208\_foil\_bulk                  | 0.285104              |
| K40\_foil\_bulk                    | 0.661791              |
| Pa234m\_foil\_bulk                 | 3686.79               |
| neutron\_external\nfull\_shielding | 0.14135               |
| total                              | 41087.2               |
