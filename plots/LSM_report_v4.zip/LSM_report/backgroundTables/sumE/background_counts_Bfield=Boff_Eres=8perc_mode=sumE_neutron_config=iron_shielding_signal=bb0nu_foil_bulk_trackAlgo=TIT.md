| **process**                        | **bkg counts in ROI** |
|:-----------------------------------|:----------------------|
| bb\_foil\_bulk                     | 0.519287              |
| Bi214\_foil\_bulk                  | 0.0708743             |
| Bi214\_radon                       | 0.0811737             |
| Tl208\_foil\_bulk                  | 0.0210117             |
| K40\_foil\_bulk                    | 0.0                   |
| Pa234m\_foil\_bulk                 | 0.0                   |
| neutron\_external\niron\_shielding | 1.07756               |
| total                              | 1.7699                |
