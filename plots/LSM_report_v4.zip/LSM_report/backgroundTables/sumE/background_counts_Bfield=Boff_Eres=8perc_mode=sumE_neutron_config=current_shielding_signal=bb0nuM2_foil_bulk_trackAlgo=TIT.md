| **process**                           | **bkg counts in ROI** |
|:--------------------------------------|:----------------------|
| bb\_foil\_bulk                        | 37389.7               |
| Bi214\_foil\_bulk                     | 5.60711               |
| Bi214\_radon                          | 7.40913               |
| Tl208\_foil\_bulk                     | 0.285806              |
| K40\_foil\_bulk                       | 1.32358               |
| Pa234m\_foil\_bulk                    | 3691.86               |
| neutron\_external\ncurrent\_shielding | 3.50874               |
| total                                 | 41099.7               |
