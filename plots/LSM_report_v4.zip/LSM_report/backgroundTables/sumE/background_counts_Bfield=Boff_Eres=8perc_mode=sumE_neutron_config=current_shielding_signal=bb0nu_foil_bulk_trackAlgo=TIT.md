| **process**                           | **bkg counts in ROI** |
|:--------------------------------------|:----------------------|
| bb\_foil\_bulk                        | 0.617266              |
| Bi214\_foil\_bulk                     | 0.0701697             |
| Bi214\_radon                          | 0.0791443             |
| Tl208\_foil\_bulk                     | 0.0205273             |
| K40\_foil\_bulk                       | 0.0                   |
| Pa234m\_foil\_bulk                    | 0.0                   |
| neutron\_external\ncurrent\_shielding | 0.652694              |
| total                                 | 1.4398                |
