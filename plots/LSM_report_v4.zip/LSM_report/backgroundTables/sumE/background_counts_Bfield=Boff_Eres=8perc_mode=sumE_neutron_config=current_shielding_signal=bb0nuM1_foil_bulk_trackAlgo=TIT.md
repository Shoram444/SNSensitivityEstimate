| **process**                           | **bkg counts in ROI** |
|:--------------------------------------|:----------------------|
| bb\_foil\_bulk                        | 21.6827               |
| Bi214\_foil\_bulk                     | 0.277097              |
| Bi214\_radon                          | 0.292225              |
| Tl208\_foil\_bulk                     | 0.0305159             |
| K40\_foil\_bulk                       | 0.0                   |
| Pa234m\_foil\_bulk                    | 0.0                   |
| neutron\_external\ncurrent\_shielding | 1.00238               |
| total                                 | 23.2849               |
