| **process**                        | **bkg counts in ROI** |
|:-----------------------------------|:----------------------|
| bb\_foil\_bulk                     | 1.39281e5             |
| Bi214\_foil\_bulk                  | 11.2402               |
| Bi214\_radon                       | 19.3619               |
| Tl208\_foil\_bulk                  | 1.6736                |
| K40\_foil\_bulk                    | 20840.5               |
| Pa234m\_foil\_bulk                 | 25839.5               |
| neutron\_external\niron\_shielding | 11.6209               |
| total                              | 1.86005e5             |
