| **process**                           | **bkg counts in ROI** |
|:--------------------------------------|:----------------------|
| bb\_foil\_bulk                        | 1.39286e5             |
| Bi214\_foil\_bulk                     | 11.2424               |
| Bi214\_radon                          | 19.3214               |
| Tl208\_foil\_bulk                     | 1.67377               |
| K40\_foil\_bulk                       | 20840.8               |
| Pa234m\_foil\_bulk                    | 25832.4               |
| neutron\_external\ncurrent\_shielding | 6.88357               |
| total                                 | 1.85999e5             |
