| **process**                        | **bkg counts in ROI** |
|:-----------------------------------|:----------------------|
| bb\_foil\_bulk                     | 1.39279e5             |
| Bi214\_foil\_bulk                  | 11.2372               |
| Bi214\_radon                       | 19.3173               |
| Tl208\_foil\_bulk                  | 1.67307               |
| K40\_foil\_bulk                    | 20840.1               |
| Pa234m\_foil\_bulk                 | 25834.4               |
| neutron\_external\nfull\_shielding | 0.332525              |
| total                              | 1.85986e5             |
