| **process**                                    | **bkg counts in ROI** |
|:-----------------------------------------------|:----------------------|
| bb\_foil\_bulk                                 | 1.39286e5             |
| Bi214\_foil\_bulk                              | 11.2384               |
| Bi214\_radon                                   | 19.3153               |
| Tl208\_foil\_bulk                              | 1.67392               |
| K40\_foil\_bulk                                | 20842.1               |
| Pa234m\_foil\_bulk                             | 25831.9               |
| neutron\_external\nno\_french\_wall\_shielding | 4.44451               |
| total                                          | 1.85996e5             |
