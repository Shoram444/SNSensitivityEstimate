| **process**                           | **bkg counts in ROI** |
|:--------------------------------------|:----------------------|
| bb\_foil\_bulk                        | 37411.5               |
| Bi214\_foil\_bulk                     | 5.60711               |
| Bi214\_radon                          | 7.40507               |
| Tl208\_foil\_bulk                     | 0.278414              |
| K40\_foil\_bulk                       | 1.32358               |
| Pa234m\_foil\_bulk                    | 3672.06               |
| neutron\_external\ncurrent\_shielding | 2.12229               |
| total                                 | 41100.3               |
