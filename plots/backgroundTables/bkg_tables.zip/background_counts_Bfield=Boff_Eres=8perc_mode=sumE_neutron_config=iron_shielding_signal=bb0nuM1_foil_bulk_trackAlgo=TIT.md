| **process**                        | **bkg counts in ROI** |
|:-----------------------------------|:----------------------|
| bb\_foil\_bulk                     | 17.3618               |
| Bi214\_foil\_bulk                  | 0.263826              |
| Bi214\_radon                       | 0.290196              |
| Tl208\_foil\_bulk                  | 0.0235851             |
| K40\_foil\_bulk                    | 0.0                   |
| Pa234m\_foil\_bulk                 | 0.0                   |
| neutron\_external\niron\_shielding | 0.87308               |
| total                              | 18.8125               |
